#!/bin/bash
git push origin refs/notes/*
