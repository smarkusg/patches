make clean
make
/c/RetroArch/retroarch.exe -L C:\\RetroArch\\cores\\picodrive_libretro.dll OpenLara.32x
