#include "common.h"

void sndInit()
{
    // TODO
}

void sndInitSamples()
{
    // TODO
}

void sndFreeSamples()
{
    // TODO
}

void* sndPlaySample(int32 index, int32 volume, int32 pitch, int32 mode)
{
    return NULL; // TODO
}

void sndPlayTrack(int32 track)
{
    // TODO
}

void sndStopTrack()
{
    // TODO
}

bool sndTrackIsPlaying()
{
    return false; // TODO
}

void sndStopSample(int32 index)
{
    // TODO
}

void sndStop()
{
    // TODO
}

void sndFill(uint8* buffer, int32 count)
{
    // TODO
}
