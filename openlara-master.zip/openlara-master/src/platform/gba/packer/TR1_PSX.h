#ifndef H_TR1_PSX
#define H_TR1_PSX

struct TR1_PSX
{
    //
};

#endif