make
./mGBA.exe C:\\Projects\\OpenLara\\src\\platform\\gba\\OpenLara.gba
