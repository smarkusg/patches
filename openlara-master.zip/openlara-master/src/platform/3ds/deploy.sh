make
/C/devkitPro/tools/bin/3dslink.exe OpenLara.3dsx -a 192.168.1.68
